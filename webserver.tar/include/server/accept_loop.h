
#ifndef NSSERVER_ACCEPT_LOOP_H_
#define NSSERVER_ACCEPT_LOOP_H_

namespace ns_server {

void AcceptLoop(int server_fd);
}  // namespace ns_server

#endif  // NSSERVER_ACCEPT_LOOP_H_
